// Backup of admin_localisation.js (Leaflet) — saved before migrating to Google Maps
// Original content preserved here as reference.

/*
PASTE ORIGINAL admin_localisation.js CONTENT HERE IF NEEDED
*/

// End of backup
