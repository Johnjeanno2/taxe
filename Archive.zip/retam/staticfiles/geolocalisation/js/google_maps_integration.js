// static/geolocalisation/js/google_maps_integration.js
class GoogleMapsIntegration {
    constructor(mapElementId) {
        this.mapElementId = mapElementId;
        this.map = null;
        this.googleMap = null;
        this.markers = [];
    }

    init() {
        this.initLeafletWithGoogle();
        this.addGoogleSearch();
    }

    initLeafletWithGoogle() {
        // Initialisation de la carte Leaflet
        this.map = L.map(this.mapElementId).setView([14.7167, -17.4677], 10);

        // Ajout de la couche Google Maps
        const googleLayer = L.gridLayer.googleMutant({
            type: 'roadmap'  // 'roadmap', 'satellite', 'terrain', 'hybrid'
        });
        googleLayer.addTo(this.map);

        // Ajout des contrôles de layers
        const baseLayers = {
            "Google Streets": googleLayer,
            "OpenStreetMap": L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            })
        };

        L.control.layers(baseLayers).addTo(this.map);
    }

    addGoogleSearch() {
        // Intégration de la recherche Google
        const searchControl = new GeoSearch.GeoSearchControl({
            provider: new GeoSearch.GoogleProvider({
                params: {
                    key: window.GOOGLE_MAPS_API_KEY,
                    language: 'fr',
                    region: 'SN'
                }
            }),
            style: 'bar',
            showMarker: true,
            showPopup: false,
            autoClose: true,
            retainZoomLevel: false,
            animateZoom: true,
            keepResult: true,
            searchLabel: 'Rechercher une adresse...',
        });

        this.map.addControl(searchControl);
    }

    addMarker(lat, lng, title, popupContent = '') {
        const marker = L.marker([lat, lng]).addTo(this.map);
        if (popupContent) {
            marker.bindPopup(popupContent);
        }
        if (title) {
            marker.bindTooltip(title);
        }
        this.markers.push(marker);
        return marker;
    }

    addZone(polygonData, properties) {
        const polygon = L.polygon(polygonData, {
            color: '#3388ff',
            weight: 2,
            fillColor: '#3388ff',
            fillOpacity: 0.2
        }).addTo(this.map);

        if (properties && properties.nom) {
            polygon.bindPopup(`<strong>${properties.nom}</strong>`);
            polygon.bindTooltip(properties.nom);
        }

        return polygon;
    }

    clearMarkers() {
        this.markers.forEach(marker => this.map.removeLayer(marker));
        this.markers = [];
    }

    fitBounds(bounds) {
        this.map.fitBounds(bounds);
    }

    getCenter() {
        return this.map.getCenter();
    }

    getZoom() {
        return this.map.getZoom();
    }
}

// Initialisation globale
document.addEventListener('DOMContentLoaded', function() {
    window.googleMapsApp = new GoogleMapsIntegration('map');
    window.googleMapsApp.init();
});