document.addEventListener('DOMContentLoaded', function() {
    fetch('/admin/gestion_contribuables/dashboard-stats/')
        .then(response => response.json())
        .then(data => {
            // Contribuables par zone
            new Chart(document.getElementById('zoneChart'), {
                type: 'bar',
                data: {
                    labels: data.contribuables_par_zone.labels,
                    datasets: [{ label: 'Contribuables', data: data.contribuables_par_zone.data, backgroundColor: '#1976d2' }]
                }
            });
            // Par type de contribuable
            new Chart(document.getElementById('typeChart'), {
                type: 'pie',
                data: {
                    labels: data.contribuables_par_type.labels,
                    datasets: [{ label: 'Type', data: data.contribuables_par_type.data, backgroundColor: ['#1976d2','#388e3c','#fbc02d','#d32f2f'] }]
                }
            });
            // Par type de taxe
            new Chart(document.getElementById('taxeChart'), {
                type: 'bar',
                data: {
                    labels: data.paiements_par_taxe.labels,
                    datasets: [{ label: 'Montant total', data: data.paiements_par_taxe.data, backgroundColor: '#388e3c' }]
                }
            });
            // Montant total par période
            new Chart(document.getElementById('montantChart'), {
                type: 'line',
                data: {
                    labels: data.montant_par_periode.labels,
                    datasets: [{ label: 'Montant total', data: data.montant_par_periode.data, borderColor: '#d32f2f', fill: false }]
                }
            });
        });
});