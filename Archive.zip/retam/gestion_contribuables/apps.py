from django.apps import AppConfig


class GestionContribuablesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion_contribuables'
    verbose_name = 'Gestion des Contribuables'
    
